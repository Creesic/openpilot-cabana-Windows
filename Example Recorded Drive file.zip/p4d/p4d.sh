#!/bin/sh
SCRIPT_DIR="$(realpath "$(dirname "$0")")"
cabana  --data_dir "$SCRIPT_DIR" $@ 2025-06-27--11-15-37--0
